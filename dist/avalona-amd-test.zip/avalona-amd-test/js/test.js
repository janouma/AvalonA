window.GreenSockGlobals = {};

require.config({
	baseUrl: '/js',

	paths: {
		jquery:    'zepto.min',
		tweenmax:  'greensock/TweenMax.min',
		tweenlite: 'shim/tweenlite',
		GSEases: 'shim/gs_eases',
		SpeedTester: 'avalona/SpeedTester.min',
		AvalonA: 'avalona/AvalonA.min',
		AvalonAnimation: 'avalona/AvalonAnimation.min'
	},

	shim: {
		jquery: {
			exports: '$'
		},
		tweenmax: {
			exports: 'window.GreenSockGlobals.TweenMax'
		}
	}
});


require(
	['jquery', 'SpeedTester', 'AvalonA', 'AvalonAnimation'],

	function test($, SpeedTester, AvalonA, AvalonAnimation){

		console.log("Starting SpeedTester");
		var speedTester = new SpeedTester('js/avalona/speed-benchmark.min.js').run();

		$(function() {
			var enableAll, frame3d, frame3d2, inner, layerCursor, outer;
			enableAll = function() {
				frame3d.enable();
				frame3d2.enable();
				$('#enable').css({
					display: 'none'
				});
				$('#enable2,#enable3').css({
					display: 'none'
				});
				$('#disable,#disable2,#disable3').css({
					display: 'block'
				});
				return $('#shuffle-all,#shuffle-one').css({
					display: 'inline'
				});
			};
			frame3d = AvalonA('body-3d', 'aa3d', {
				zAttr: 'data-aaz',
				fy: function(rotation) {
					return 0.75 * rotation;
				},
				fx: function(rotation) {
					return 2 * rotation;
				},
				activeArea: {
					attachment: 'scroll',
					width: '75%',
					height: 350
				},
				on: {
					startrotation: function() {
						return console.log("3d rotation on");
					},
					endrotation: function() {
						return console.log("3d rotation off");
					}
				},
				animation: AvalonAnimation.Balance()
			});
			frame3d2 = AvalonA('body-3d', 'a3d2', {
				zAttr: 'data-aaz',
				fy: function(rotation) {
					return 0.75 * rotation;
				},
				fx: function(rotation) {
					return 2 * rotation;
				},
				activeArea: {
					position: {
						x: 50,
						y: 250
					},
					attachment: 'scroll',
					width: 350,
					height: 350
				},
				on: {
					startrotation: function() {
						return console.log("3d II rotation on");
					},
					endrotation: function() {
						return console.log("3d II rotation off");
					}
				},
				animation: AvalonAnimation.Balance(),
				idleTimeout: -1,
				debug: true
			});
			layerCursor = 0;
			outer = $('[data-outter]');
			outer.attr('id', outer.attr('data-outter'));
			inner = $('[data-inner]');
			inner.attr('id', inner.attr('data-inner'));
			$('#enable').click(enableAll);
			$('#disable').click(function() {
				$('#shuffle-all,#shuffle-one').css({
					display: 'none'
				});
				$(this).css({
					display: 'none'
				});
				$('#disable2,#disable3').css({
					display: 'none'
				});
				$('#enable,#enable2,#enable3').css({
					display: 'block'
				});
				frame3d.disable();
				return frame3d2.disable();
			});
			$('#shuffle-all').click(function() {
				$('[data-aaz]').each(function() {
					return $(this).attr({
						'data-aaz': Math.round(Math.random() * 400 - 200)
					});
				});
				return frame3d.zRefresh();
			});
			$('#shuffle-one').click(function() {
				var node;
				node = $('[data-aaz]').eq(layerCursor);
				node.attr({
					'data-aaz': Math.round(Math.random() * 400 - 200)
				});
				frame3d.zRefresh(node);
				return layerCursor = (layerCursor + 1) % $('[data-aaz]').size();
			});
			$('#enable2').click(function() {
				frame3d2.enable();
				$(this).css({
					display: 'none'
				});
				return $('#disable2').css({
					display: 'block'
				});
			});
			$('#disable2').click(function() {
				frame3d2.disable();
				$(this).css({
					display: 'none'
				});
				return $('#enable2').css({
					display: 'block'
				});
			});
			$('#enable3').click(function() {
				frame3d.enable();
				$(this).css({
					display: 'none'
				});
				return $('#disable3').css({
					display: 'block'
				});
			});
			$('#disable3').click(function() {
				frame3d.disable();
				$(this).css({
					display: 'none'
				});
				return $('#enable3').css({
					display: 'block'
				});
			});
			$('#hide').click(function() {
				$('#aa3d,#a3d2').css({
					display: 'none'
				});
				$(this).css({
					display: 'none'
				});
				return $('#show').css({
					display: 'block'
				});
			});
			$('#show').click(function() {
				$('#aa3d,#a3d2').css({
					display: 'block'
				});
				$(this).css({
					display: 'none'
				});
				return $('#hide').css({
					display: 'block'
				});
			});
			speedTester.oncomplete(function(message) {
				console.log("speed: " + message.speed);
				enableAll();
			});
		});
	}
);