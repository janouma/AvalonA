define('GSEases', ['tweenmax'], function defineGSEases(){
	return {
		Linear: window.GreenSockGlobals.Linear,
		Power1: window.GreenSockGlobals.Power1
	};
});