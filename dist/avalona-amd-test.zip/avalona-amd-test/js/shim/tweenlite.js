define('tweenlite', ['tweenmax'], function defineTweenLite(){
	return window.GreenSockGlobals.TweenLite;
});